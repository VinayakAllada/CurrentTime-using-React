import DigitalClock from './DigitalClock.jsx'

function App() {
  return (<DigitalClock />);
}

export default App
